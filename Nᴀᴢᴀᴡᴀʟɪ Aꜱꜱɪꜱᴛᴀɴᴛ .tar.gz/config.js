/**
 * Global Configuration for WhatsApp MD Bot
 */

module.exports = {
    // Bot Owner Configuration
    ownerNumber: ['923357191832'], // Add your number without + or spaces (e.g., 919876543210)
    ownerName: ['Erum Shah'], // Owner names corresponding to ownerNumber array
    
    // Bot Configuration
    botName: 'Nᴀᴢᴀᴡᴀʟɪ Aꜱꜱɪꜱᴛᴀɴᴛ',
    prefix: '.',
    sessionName: 'session',
    sessionID: process.env.SESSION_ID || 'KnightBot!H4sIAAAAAAAAA5VU25KiSBT8l3qVmOYiconoiEGkERGvqOjGPJRQQCk3iwKBCf99A3t6Zh52Z3t5Kg5EnjyZeeo7yHJcIhu1QP0OCoJrSFF/pG2BgArGVRgiAhgQQAqBCtZv2L64rE0HkRcbRl0LtvKCUejbldEML4mlC353iF5y3noFDwYU1TnB/h8Az7tWO3CueRcvZuYe8KkbLU6p5BqLzj5ulVzwmyo9d1f+UL6CR48IMcFZZBQxShGBiY3aFcTkc/SviyYrp0G25HXzMvdkj2yVrSyRo1gneXdAu5pcbHY9PR2On6P/AgtPu+1XrqSvB/zwyJ+h2BItm7ZSh6iIsXtrzVW+tNnjO/0SRxkKrABlFNP207rnU2s29vT7Riq7btbIhagQLi7aLb3vhVVwniPStPOdS/lPEpeE1LGuJEhJ420M0+7ay1Q413XsevuldOHZ3VmUFrwZx8Pfia/IR1au/0d3dhqRdMAdXmTPZOO6I/5mmXZxlI7lyoHr5bzzVvONTzlD/hz9JtOdILFmw81RbxdS4Ie3t1Go7VbEPbXVJO2arjvZ41Qxo1/0Ia3In1jGlyrq4tFmGA0d53yRxrEMV3fxIt2K5csoL6MwMpPDJmGVUlxsrFlaD8+j1jzzu6EjzG7hsbl5+ILuC7nB51U131+7dXR/fU50Ra0VAJV7MICgCJeUQIrz7FmTZQbAoN4inyD6lBcIlist8al01j4/2WhvyiL1EKe7S2NWmTVvSuwsEt82HI6MV8CAguQ+KksUTHFJc9I6qCxhhEqg/vWNARlq6LtxfTuBY0CISUl3WVUkOQw+XP34CH0/rzK6bTNf7w+IAJX9VUaU4iwqex2rDBI/xjXSY0hLoIYwKdHPCRFBAVApqdDPrdXzoBd+wm0NSRvLgAHp0xAcABUovCCIEqdwssCrwtfyy71HhUXxJUMUMCB5/sVzisKznCIIHKsMFVX42tcfP/n1cAGiECclUIE+47nuuJsYFpQG/tA0NSPS9EgDv+b5CMa78Lt4NTUMrU73l1jkdc+cn4jblbRAbDaiJ1FeW8ollI7Fznr9B5Aegd+FA3IyV9MtT23ldvDfBhO/4kk29sNyvx6eWLaw9oPFlZtLYaqdR4pQxXdt4ojb7hqMlXU8IFzezVdU9MeHk/PibfU+RQwIUI199HsztA9m1/loa9n55Kgv7qPjztHbhRMeiorzJiNHGtXXY5pj7uS44Tb0zIOnTdxorJvD7Rzeh1dhulyfXHO504tFwY/jjR5p75F9rkzy46rCzzD1TvWvIUbPzc9g799/OvfOu88X+2B+g/hxlfzLOo73lts0Y20uJschCqKkwTxkZWkOPTobkAMKDX11FAa8vdfB4/GNAUUCaZiTFKgAZgHJcQAYQPKqD6yVhfkfmumaY+nr6K0fPIEl1X4tgYtTVFKYFkDlJGnEyeyIkxmQtlpRbCmkH7sDtP4ZX2/g8TdIoKtiVwcAAA==',
    newsletterJid: '120363425498536494@newsletter', // Newsletter JID for menu forwarding
    updateZipUrl: 'https://github.com/mruniquehacker/KnightBot-Mini/archive/refs/heads/main.zip', // URL to latest code zip for .update command
    
    // Sticker Configuration
    packname: 'Nᴀᴢᴀᴡᴀʟɪ Aꜱꜱɪꜱᴛᴀɴᴛ',
    
    // Bot Behavior
    selfMode: false, // Private mode - only owner can use commands
    autoRead: false,
    autoTyping: false,
    autoBio: false,
    autoSticker: false,
    autoReact: false,
    autoReactMode: 'bot', // set bot or all via cmd
    autoDownload: false,
    
    // Group Settings Defaults
    defaultGroupSettings: {
      antilink: false,
      antilinkAction: 'delete', // 'delete', 'kick', 'warn'
      antitag: false,
      antitagAction: 'delete',
      antiall: false, // Owner only - blocks all messages from non-admins
      antiviewonce: false,
      antibot: false,
      anticall: false, // Anti-call feature
      antigroupmention: false, // Anti-group mention feature
      antigroupmentionAction: 'delete', // 'delete', 'kick'
      welcome: false,
      welcomeMessage: '╭╼━≪•𝙽𝙴𝚆 𝙼𝙴𝙼𝙱𝙴𝚁•≫━╾╮\n┃𝚆𝙴𝙻𝙲𝙾𝙼𝙴: @user 👋\n┃Member count: #memberCount\n┃𝚃𝙸𝙼𝙴: time⏰\n╰━━━━━━━━━━━━━━━╯\n\n*@user* Welcome to *@group*! 🎉\n*Group 𝙳𝙴𝚂𝙲𝚁𝙸𝙿𝚃𝙸𝙾𝙽*\ngroupDesc\n\n> *ᴘᴏᴡᴇʀᴇᴅ ʙʏ botName*',
      goodbye: false,
      goodbyeMessage: 'Goodbye @user 👋 We will never miss you!',
      antiSpam: false,
      antidelete: false,
      nsfw: false,
      detect: false,
      chatbot: false,
      autosticker: false // Auto-convert images/videos to stickers
    },
    
    // API Keys (add your own)
    apiKeys: {
      // Add API keys here if needed
      openai: '',
      deepai: '',
      remove_bg: ''
    },
    
    // Message Configuration
    messages: {
      wait: '⏳ Please wait...',
      success: '✅ Success!',
      error: '❌ Error occurred!',
      ownerOnly: '👑 This command is only for bot owner!',
      adminOnly: '🛡️ This command is only for group admins!',
      groupOnly: '👥 This command can only be used in groups!',
      privateOnly: '💬 This command can only be used in private chat!',
      botAdminNeeded: '🤖 Bot needs to be admin to execute this command!',
      invalidCommand: '❓ Invalid command! Type .menu for help'
    },
    
    // Timezone
    timezone: 'Asia/Karachi',
    
    // Limits
    maxWarnings: 3,
    
    // Social Links (optional)
    social: {
      github: 'https://github.com/hamidanoo',
      instagram: 'https://instagram.com/hamidanoo56',
      youtube: 'https://www.facebook.com/hamidanoo56'
    }
};
  