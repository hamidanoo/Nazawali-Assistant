const axios = require('axios');

module.exports = {
  name: 'tts',
  aliases: ['speak', 'say'],
  category: 'general',
  description: 'Convert text to speech',
  usage: '.tts <text>',
  
  async execute(sock, msg, args, extra) {
    try {
      const chatId = extra.from;
      const text = args.join(' ');

      if (!text) {
        return extra.reply('Example: .tts hello bro');
      }

      // Google TTS (working)
      const encoded = encodeURIComponent(text);
      const url = `https://translate.google.com/translate_tts?ie=UTF-8&q=${encoded}&tl=hi&client=tw-ob`;

      const res = await axios.get(url, {
        responseType: 'arraybuffer',
        headers: {
          'User-Agent': 'Mozilla/5.0'
        }
      });

      const buffer = Buffer.from(res.data);

      await sock.sendMessage(chatId, {
        audio: buffer,
        mimetype: 'audio/mpeg'
      }, { quoted: msg });

    } catch (err) {
      console.log(err);
      extra.reply('❌ TTS failed. Check internet or try again.');
    }
  }
};